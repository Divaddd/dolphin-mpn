Drag a Mario Party 5 (USA) ISO onto the .BAT file to patch it.

Refer to this list for descriptions of capsules:
https://www.mariowiki.com/Mario_Party_5#Capsules